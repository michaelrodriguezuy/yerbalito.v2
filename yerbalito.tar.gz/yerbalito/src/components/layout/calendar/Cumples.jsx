import React from 'react'

const Cumples = () => {
  return (
    <div>Cumples</div>
  )
}

export default Cumples