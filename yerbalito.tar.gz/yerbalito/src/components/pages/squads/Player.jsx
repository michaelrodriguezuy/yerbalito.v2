import React from 'react'

const Player = () => {
  return (
    <div className='container'>Jugador</div>
  )
}

export default Player