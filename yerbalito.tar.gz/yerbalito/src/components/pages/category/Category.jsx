
const Category = () => {
  return (
    <div className="page-container-scroll">Category</div>
  )
}

export default Category