import TypingWelcome from './TypingWelcome';
import "./Home.css";

const Home = () => {
  return (
    <div className="page-container">
      <TypingWelcome />
    </div>
  );
};

export default Home;
