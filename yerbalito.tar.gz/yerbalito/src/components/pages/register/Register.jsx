
const Register = () => {
  return (
    <div className="page-container-scroll">Registro</div>
  )
}

export default Register